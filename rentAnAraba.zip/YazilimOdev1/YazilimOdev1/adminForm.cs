﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace YazilimOdev1
{
    public partial class adminForm : Form
    {
        string connectionStringadmin = @"Server=localhost\SQLEXPRESS;Initial Catalog= KullaniciKayitDB;Trusted_Connection=True;";

        public adminForm()
        {
            InitializeComponent();
        }

        private void adminForm_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            using (SqlConnection sqlCon = new SqlConnection(connectionStringadmin))
            {

                //işte burada, eğer hata yapılmamışsa, bu değerleri sql e gönderiyor.
                sqlCon.Open();
                SqlCommand sqlCmd = new SqlCommand("arabaEklePatron7", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@arabaModel", txtModel.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@fiyat", txtFiyat.Text.Trim());
                //yani girilen değerleri sql deki ilgili alanlara yerleştirdi, bunu arabalarda da kullanacağız. 
                sqlCmd.ExecuteNonQuery();
                MessageBox.Show("Basarili!");
                SqlCommand cmd = new SqlCommand("Select arabaModel, fiyat, arabaID from tblArabalar7", sqlCon);
                
                SqlDataReader da = cmd.ExecuteReader();
                while (da.Read())
                {
                    // 
                    listBox1.Items.Add(da.GetValue(0).ToString() + "     " + da.GetValue(1).ToString()+ "    " + da.GetValue(2).ToString()) ; //burası araba modeli 
                                                                          //  "         " + da.GetValue(1).ToString() //burası fiyatı
                                                                          //  + "        " +da.GetValue(2).ToString()) ; ; //burası araba ID
                                                                          //hangi modeli seçtiyse, onu db ye gönderip işlemek istiyor
                }

            }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
