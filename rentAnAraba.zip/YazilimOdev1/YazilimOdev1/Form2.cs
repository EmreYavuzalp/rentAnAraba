﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace YazilimOdev1
{
    public partial class Form2 : Form
    {
        public static String girisID2;

        public Form2()
        {
            InitializeComponent();

        }
        
        public void btnGiris_Click(object sender, EventArgs e)
        {

            String girisID = txtKAdi2.Text;
            //burdaki kod form1 den baya değişik, çünkü orada arama yoktu ama burada var mecburen. Kullanıcı adı db de var mı ona bakıyoruz mecburen.
            SqlConnection sqlcon = new SqlConnection(@"Server=localhost\SQLEXPRESS;Initial Catalog= KullaniciKayitDB;Trusted_Connection=True;MultipleActiveResultSets=true;");
            sqlcon.Open();
            SqlCommand cmd = new SqlCommand("Select userID from tblKullanici where KullaniciAdi='"+girisID+"'", sqlcon);
            SqlDataReader da = cmd.ExecuteReader();
            while (da.Read())
            {
                girisID2 = da.GetValue(0).ToString();
            }
            string query = "Select * from tblKullanici Where KullaniciAdi ='" + txtKAdi2.Text.Trim() + "' and Sifre = '" + txtSifre2.Text.Trim()+"'";
            //string query2 = "Select userID from tblKullanici Where KullaniciAdı ='" + girisID + "'";
            // String bisey= new SqlCommand("Select userID from tblKullanici where @KullaniciAdi =girisID", sqlcon).ToString();
            
            SqlDataAdapter adapter = new SqlDataAdapter(query,sqlcon);
            DataTable dtbl = new DataTable();
            
            adapter.Fill(dtbl);
            if(dtbl.Rows.Count==1)
            {
                //Hocam admin id vs oluşturabilirdim fakat sql de tabloyu drop etmem gerekiyordu. Zaman meselesi yüzünden böyle yaptım.
                //bu Düzce kullanıcısı adminmiş gibi farzediniz lütfen.
                if (txtKAdi2.Text=="Duzce")
                {

                    this.Hide();
                    adminForm adminFormu = new adminForm();
                    adminFormu.Show();
                    MessageBox.Show("Başarılı giriş hoşgeldiniz sayın admin!");
                }
                else
                {
                    this.Hide();
                    kullaniciForm kullaniciFormu = new kullaniciForm();
                    kullaniciFormu.Show();
                    MessageBox.Show("Başarılı giriş, hoşgeldiniz " + txtKAdi2.Text +" araba kiralamaya başlayabilirsiniz");
                }
                //eğer uyuşma varsa ve tablo boş değilse demek şöyle yap.
                //fakat burada bir if daha açıp, eğer adminse şuraya, değilse başka bir yere yönlendirebiliriz rahatça?
                //Form3 admin paneli olsun, Form4 ise kullanıcının paneli olsun.
                
            }
            else
            {
                MessageBox.Show("Yanlış kullanıcı adı veya şifre");
            }
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
