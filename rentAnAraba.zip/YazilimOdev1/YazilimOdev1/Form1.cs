﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace YazilimOdev1
{
    public partial class Form1 : Form
    {
        string connectionString = @"Server=localhost\SQLEXPRESS;Initial Catalog= KullaniciKayitDB;Trusted_Connection=True;";
        //ilk connection burada başlıyor
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnKaydol_Click(object sender, EventArgs e)
        {

            if (txtKAdi.Text == "" || txtSifre.Text == "")
                MessageBox.Show("Boşluk bir şifre değildir...");
            else if (txtSifre.Text != txtSifreTekrar.Text)
                MessageBox.Show("Şifreler tutmuyor.");
            else
            {

                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {

                    //işte burada, eğer hata yapılmamışsa, bu değerleri sql e gönderiyor.
                    sqlCon.Open();
                    SqlCommand sqlCmd = new SqlCommand("KullaniciEkle", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@Ad", txtAd.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Soyad", txtSoyad.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@KullaniciAdi", txtKAdi.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Sifre", txtSifre.Text.Trim());
                    //yani girilen değerleri sql deki ilgili alanlara yerleştirdi, bunu arabalarda da kullanacağız. 
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Basarili!");
                    this.Hide();
                    //mesela burda bir form 3 oluştururuz, bu da admin formu olur. if txtkadi adminse form3 e gitsin falan. id si 1 olan admin olsun istiyorum ben mesela. 
                    //ya da, DuzceUni yazarsa kullanıcı, o ekrana gitsin. Şimdi onu tasarlamakla uğraşamam.

                    Form2 frm2 = new Form2();
                    frm2.Show();
                }
            }
        }

        private void btnGiris_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 frm2 = new Form2();
            frm2.Show();
        }
    }
}
