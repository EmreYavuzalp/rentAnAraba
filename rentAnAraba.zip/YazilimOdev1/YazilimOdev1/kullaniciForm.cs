﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace YazilimOdev1
{
    public partial class kullaniciForm : Form
    {
        string connectionStringKullanici = @"Server=localhost\SQLEXPRESS;Initial Catalog= KullaniciKayitDB;Trusted_Connection=True;MultipleActiveResultSets=true;";

        public kullaniciForm()
        {
            InitializeComponent();

            using (SqlConnection sqlCon = new SqlConnection(connectionStringKullanici))
            {
                
                sqlCon.Open();
                SqlCommand cmd = new SqlCommand("Select arabaModel, fiyat, arabaID from tblArabalar7 where kiraID IS NULL", sqlCon);
                //SqlCommand cmd= new SqlCommand("Select userID from tblKullanici where @KullaniciAdi =girisID", sqlcon);
                SqlDataReader da = cmd.ExecuteReader();
                while (da.Read())
                {
                    checkedListBox1.Items.Add(da.GetValue(0).ToString()); 
                    listBox1.Items.Add(da.GetValue(1).ToString());
                    listBox2.Items.Add(da.GetValue(2).ToString());
                }
                
            }

        }

            private void kullaniciForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            String toplamFiyat;
            String arabaID="99";
            for (int i = 0; i < checkedListBox1.Items.Count; i++)
            {
                if (checkedListBox1.GetItemChecked(i) == true)
                {

                    int fiyat = int.Parse(listBox1.Items[i].ToString());
                     arabaID = (listBox2.Items[i].ToString());
                    int sure = Convert.ToInt32(textBox4.Text); 
                    toplamFiyat = (fiyat * sure).ToString();
                    
                        if (listBox3.Items.Contains(checkedListBox1.Items))
                        {
                            
                        }
                    else
                    {
                        listBox3.Items.Add(checkedListBox1.Items[i].ToString() + "  " + toplamFiyat);
                    }
                    
                }

            }
            string girisID = Form2.girisID2;
            string kiraID = girisID + arabaID;
            SqlConnection sqlCon = new SqlConnection(connectionStringKullanici);
            sqlCon.Open();
            using (SqlCommand cmd = new SqlCommand("UPDATE tblArabalar7 SET kiraID=@kiraID WHERE arabaID=@arabaID;", sqlCon))
                {
                    cmd.Parameters.AddWithValue("@kiraID", Convert.ToInt32(kiraID));
                    cmd.Parameters.AddWithValue("@arabaID", Convert.ToInt32(arabaID));
                    cmd.ExecuteNonQuery();
                }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {                    }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }

        
    }

